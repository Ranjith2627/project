
$("#email").blur(function () {
    var email = $("#email").val().toLowerCase();
    $("#email").val(email)
});

$("#login").click(function () {

    var email = $("#email").val();

    var getData = {
        "tableName": "tblUserDetails",
        "crudOperation": "VIEW",
        "columnData": [
            {
                "columnName":"emailID",
                "columnValue":email
            }
        ]
    }

    recordGetPost(getData).then(function (res) {
        const rows = res[0];
        if(res.length == 1){
            $("#successAlert").show(100);
            window.open(`http://localhost:90/index.html?auth=true&mail=${res[0].emailID}`,"_self");
        }
        else{
            $("#failureAlert").show(100);
        }
    });

});