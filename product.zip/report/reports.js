
//table row mouseover and mouseleave
function rowMouseOver(thisval) {
    let icon = $(thisval).find(".icon i");
    // icon.attr("style", "display:block;cursor:pointer;");
}
function rowMouseLeave(thisval) {
    let icon = $(thisval).find(".icon i");
    // icon.attr("style", "display:none;cursor:pointer;");
}


