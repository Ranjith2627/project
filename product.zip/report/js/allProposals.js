
var getData = {
    "tableName": "ClientMaster",
    "crudOperation": "VIEW",
    "columnData": [
        {
            "columnName":"status",
            "columnValue":"Enquiry"
        }
    ]
}

recordGetPost(getData).then(function(res){
    if (res.length > 0) {
        $("#reportTable").show(400);
        $(".empty").hide();

        var sno = 0;
        for (let i = 0; i < res.length; i++) {
            sno += 1;
            const rows = res[i];
            $("#reportTable tbody").append(`<tr onclick="proposalOpen(this)">
            <td class="icon"><i id="delete" class="fa-solid fa-trash" onclick="deleteMode(this)"></i><i id="edit" class="fa-solid fa-pen-to-square" onclick="editMode(this)"></i><i id="view" data-bs-toggle="modal" data-bs-target="#exampleModal" class="fa-sharp fa-solid fa-eye" onclick="viewMode(this)"></i></td>
            <td class="clientName">${rows.clientName}</td>
            <td class="clientCode">${rows.clientCode}</td>
            <td class="email">${rows.email}</td>
            <td class="mobile">${rows.mobile}</td>
            <td class="clientGroup">${rows.clientGroup}</td>
            <td class="status">${rows.status}</td>
            </tr>`);
        }
        $('#reportTable').DataTable();
        $("#reportTable_filter>label").attr("style","display:flex;");
    }
    else {
        $("#reportTable").hide();
        $(".empty").css("display", "flex");
    }
});

// View Mode
function viewMode(thisval) {
    let viewCliN = $(thisval).parent().parent().find(".clientName").text();
    let viewCliC = $(thisval).parent().parent().find(".clientCode").text();
    let viewEmail = $(thisval).parent().parent().find(".email").text();
    let viewMobile = $(thisval).parent().parent().find(".mobile").text();
    let viewcliG = $(thisval).parent().parent().find(".clientGroup").text();
    let viewStatus = $(thisval).parent().parent().find(".status").text();

    $("#clientName").val(viewCliN);
    $("#clientCode").val(viewCliC);
    $("#email").val(viewEmail);
    $("#mobile").val(viewMobile);
    $("#clientGroup").val(viewcliG);
    $("#status").val(viewStatus);
    
}

// Edit Mode
function editMode(thisval) {
    $(thisval).after(`<i id="save" class="fa-solid fa-floppy-disk" onclick="save(this)"></i>`);
    $(thisval).attr("style", "display:none;");
    let selectedRow = $(thisval).parent().parent();
    selectedRow.children().not(".icon").attr("contenteditable", "true");
}
//Save Function
function save(thisval) {
    let clientName = $(thisval).parent().parent().find(".clientName").text();
    let clientCode = $(thisval).parent().parent().find(".clientCode").text();
    let email = $(thisval).parent().parent().find(".email").text();
    let mobile = $(thisval).parent().parent().find(".mobile").text();
    let clientGroup = $(thisval).parent().parent().find(".clientGroup").text();
    let status = $(thisval).parent().parent().find(".status").text();


    // Clients POST API
    var Update = {
        "tableName": "ClientMaster",
        "crudOperation": "UPDATE",
        "columnData": [
            {
                "columnName": "clientName",
                "columnValue": clientName
            },
            {
                "columnName": "clientCode",
                "columnValue": clientCode
            },
            {
                "columnName": "email",
                "columnValue": email
            },
            {
                "columnName": "mobile",
                "columnValue": mobile
            },
            {
                "columnName": "clientGroup",
                "columnValue": clientGroup
            },
            {
            "columnName": "status",
            "columnValue": status
            }
        ]
    }
    recordOperation(Update);

    $(thisval).after(`<i id="edit" class="fa-solid fa-pen-to-square" onclick="clientEditMode(this)"></i>`);
    $(thisval).attr("style", "display:none;");
    let selectedRow = $(thisval).parent().parent();
    selectedRow.children().not(".icon").attr("contenteditable", "false");
}

// Delete Mode
function deleteMode(thisval) {
    let delRec = $(thisval).parent().parent().find(".clientName").text();
    
    var Delete = {
        "tableName": "ClientMaster",
        "crudOperation": "DELETE",
        "columnData": [
            {
                "columnName": "clientName",
                "columnValue": delRec
            }
        ]
    }
    recordOperation(Delete);
}


$("#addRec").click(function(){
    window.open("http://localhost:90/form/clients.html?status=Enquiry","_self");
});






function proposalOpen(thisval){
    var clientName = $(thisval).find(".clientName").text();
    window.open(`http://localhost:90/template/proposalTemplate.html?client=${clientName}`,"_self");
}