
// function getAllClients(data) { } function getAllAssignmentNature(data) { } function getAllContracts(data) { } function getAllProjects(data) { }





var getData = {
    "tableName": "AllEmployees",
    "crudOperation": "VIEW",
    "columnData": null
}

recordGetPost(getData).then(function(res){
    if (res.length > 0) {
        $("#reportTable").show(400);
        $(".empty").hide();

        var sno = 0;
        for (let i = 0; i < res.length; i++) {
            sno += 1;
            const rows = res[i];
            $("#reportTable tbody").append(`<tr onmouseover="rowMouseOver(this)" onmouseleave="rowMouseLeave(this)">
            <td class="icon"><i id="delete" class="fa-solid fa-trash" onclick="deleteMode(this)"></i><i id="edit" class="fa-solid fa-pen-to-square" onclick="editMode(this)"></i><i id="view" data-bs-toggle="modal" data-bs-target="#exampleModal" class="fa-sharp fa-solid fa-eye" onclick="viewMode(this)"></i></td>
            <td class="employeeName">${rows.employeeName}</td>
            <td class="employeeCode">${rows.employeeCode}</td>
            <td class="department">${rows.department}</td>
            <td class="designation">${rows.designation}</td>
            <td class="dateOfJoining">${rows.dateOfJoining}</td>
            <td class="dateOfResignation">${rows.dateOfResignation}</td>
            </tr>`);
        }
        $('#reportTable').DataTable();
        $("#reportTable_filter>label").attr("style","display:flex;");
    }
    else {
        $("#reportTable").hide();
        $(".empty").css("display", "flex");
    }
});

// View Mode
function viewMode(thisval) {

    let employeeCode = $(thisval).parent().parent().find(".employeeCode").text();
    let employeeName = $(thisval).parent().parent().find(".employeeName").text();
    let department = $(thisval).parent().parent().find(".department").text();
    let designation = $(thisval).parent().parent().find(".designation").text();
    let doj = $(thisval).parent().parent().find(".dateOfJoining").text();
    let dor = $(thisval).parent().parent().find(".dateOfResignation").text();


    $("#employeeCode").val(employeeCode);
    $("#employeeName").val(employeeName);
    $("#department").val(department);
    $("#designation").val(designation);
    $("#dateOfJoining").val(doj);
    $("#dateOfResignation").val(dor);
    
}

// Edit Mode
function editMode(thisval) {
    $(thisval).after(`<i id="save" class="fa-solid fa-floppy-disk" onclick="save(this)"></i>`);
    $(thisval).attr("style", "display:none;");
    let selectedRow = $(thisval).parent().parent();
    selectedRow.children().not(".icon").attr("contenteditable", "true");
}
//Save Function
function save(thisval) {
    let employeeCode = $(thisval).parent().parent().find(".employeeCode").text();
    let employeeName = $(thisval).parent().parent().find(".employeeName").text();
    let department = $(thisval).parent().parent().find(".department").text();
    let designation = $(thisval).parent().parent().find(".designation").text();
    let doj = $(thisval).parent().parent().find(".dateOfJoining").text();
    let dor = $(thisval).parent().parent().find(".dateOfResignation").text();


    // Clients POST API
    var Update = {
        "tableName": "AllEmployees",
        "crudOperation": "UPDATE",
        "columnData": [
            {
                "columnName": "employeeCode",
                "columnValue": employeeCode
            },
            {
                "columnName": "employeeName",
                "columnValue": employeeName
            },
            {
                "columnName": "department",
                "columnValue": department
            },
            {
                "columnName": "designation",
                "columnValue": designation
            },
            {
                "columnName": "dateOfJoining",
                "columnValue": doj
            },
            {
                "columnName": "dateOfResignation",
                "columnValue": dor
            }
        ]
    }
    recordOperation(Update);

    $(thisval).after(`<i id="edit" class="fa-solid fa-pen-to-square" onclick="clientEditMode(this)"></i>`);
    $(thisval).attr("style", "display:none;");
    let selectedRow = $(thisval).parent().parent();
    selectedRow.children().not(".icon").attr("contenteditable", "false");
}

// Delete Mode
function deleteMode(thisval) {
    let delRec = $(thisval).parent().parent().find(".employeeCode").text();
    
    var Delete = {
        "tableName": "AllEmployees",
        "crudOperation": "DELETE",
        "columnData": [
            {
                "columnName": "employeeCode",
                "columnValue": delRec
            }
        ]
    }
    recordOperation(Delete);
}




$("#plus>i").click(function () {
    window.open("http://localhost:90/form/employees.html", "_self");
});

$("#addRec").click(function(){
    window.open("http://localhost:90/form/employees.html","_self");
});



































// // Fetch All Departments API

// function getAllEmployees(data) {

//     if (data.length > 0) {
//         $("#reportTable").show(400);
//         $(".empty").hide();

//         var sno = 0;
//         for (let i = 0; i < data.length; i++) {
//             sno += 1;
//             const rows = data[i];
//             $("#reportTable tbody").append(`<tr onmouseover="rowMouseOver(this)" onmouseleave="rowMouseLeave(this)">
            // <td class="icon"><i id="delete" class="fa-solid fa-trash" onclick="clientRecDeletion(this)"></i><i id="edit" class="fa-solid fa-pen-to-square" onclick="clientEditMode(this)"></i><i id="view" class="fa-sharp fa-solid fa-eye" onclick="clientViewMode(this)"></i></td>
            // <td class="employeeCode">${rows.employeeCode}</td>
            // <td class="employeeName">${rows.employeeName}</td>
            // <td class="department">${rows.department}</td>
            // <td class="designation">${rows.designation}</td>
            // <td class="dateOfJoining">${rows.dateOfJoining}</td>
            // <td class="dateOfResignation">${rows.dateOfResignation}</td>
//             </tr>`);
//         }
        
//         $('#reportTable').DataTable();
//     }
//     else {
//         $("#reportTable").hide();
//         $(".empty").css("display", "flex");
//     }

//     var test = $('#reportTable>table').DataTable();

// }

// // View Mode
// function clientViewMode(thisval) {
//     let appId = $(thisval).parent().parent().find(".employeeCode").text();
//     window.open(`http://localhost:90/form/employees.html?id=${appId}`, "_self");
// }
// // Delete Mode
// function clientRecDeletion(thisval) {
    // let delEmpCode = $(thisval).parent().parent().find(".employeeCode").text();
    // let delEmpName = $(thisval).parent().parent().find(".employeeName").text();
    // let delDepartment = $(thisval).parent().parent().find(".department").text();
    // let delDesignation = $(thisval).parent().parent().find(".designation").text();
    // let delDoj = $(thisval).parent().parent().find(".dateOfJoining").text();
    // let delDor = $(thisval).parent().parent().find(".dateOfResignation").text();


//     var departmentDelete = {
//         "employeeCode": delEmpCode,
//         "employeeName": delEmpName,
//         "department": delDepartment,
//         "designation": delDesignation,
//         "dateOfJoining": delDoj,
//         "dateOfResignation": delDor,
//         "crudOperation": "DELETE"
//     }
//     fetch("http://localhost:86/api/Prototype/CRUDEmployees", {
//         method: "POST",
//         headers: { "Content-Type": "application/json", 'accept': 'text/plain' },
//         body: JSON.stringify(departmentDelete)
//     }).then(res => res.text()).then(function (message) {
//         console.log(message);
//         window.location.reload();
//     });
// }



// //Save Function
// function save(thisval) {
//     let employeeName = $("#employeeName").val();
//     let employeeCode = $("#employeeCode").val();
//     let department = $("#department").val();
//     let designation = $("#designation").val();
//     let doj = $("#dateOfJoining").val();
//     let dor = $("#dateOfResignation").val();

//     var employeesUpdate = {
//         "employeeCode": employeeCode,
//         "employeeName": employeeName,
//         "department": department,
//         "designation": designation,
//         "dateOfJoining": doj,
//         "dateOfResignation": dor,
//         "crudOperation": "UPDATE"
//     }
//     fetch("http://localhost:86/api/Prototype/CRUDEmployees", {
//         method: "POST",
//         headers: { "Content-Type": "application/json", 'accept': 'text/plain' },
//         body: JSON.stringify(employeesUpdate)
//     }).then(res => res.text()).then(function (message) {
//         console.log(message);
//     });

//     $(thisval).after(`<i id="edit" class="fa-solid fa-pen-to-square" onclick="clientEditMode(this)"></i>`);
//     $(thisval).attr("style", "display:none;");
//     let selectedRow = $(thisval).parent().parent();
//     selectedRow.children().not(".icon").attr("contenteditable", "false");
// }


