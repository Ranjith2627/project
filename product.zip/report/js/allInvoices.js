
var getData = {
    "tableName": "AllInvoices",
    "crudOperation": "VIEW",
    "columnData": null
}

recordGetPost(getData).then(function(res){
    if (res.length > 0) {
        $("#reportTable").show(400);
        $(".empty").hide();

        var sno = 0;
        for (let i = 0; i < res.length; i++) {
            sno += 1;
            const rows = res[i];
            $("#reportTable tbody").append(`<tr onmouseover="rowMouseOver(this)" onmouseleave="rowMouseLeave(this)">
            <td class="icon"><i id="delete" class="fa-solid fa-trash" onclick="deleteMode(this)"></i><i id="edit" class="fa-solid fa-pen-to-square" onclick="editMode(this)"></i><i id="view" data-bs-toggle="modal" data-bs-target="#exampleModal" class="fa-sharp fa-solid fa-eye" onclick="viewMode(this)"></i></td>
            <td class="projectCode">${rows.projectCode}</td>
            <td class="invoiceNumber">${rows.invoiceNumber}</td>
            <td class="amount">${rows.amount}</td>
            <td class="status">${rows.status}</td>
            </tr>`);
        }
        $('#reportTable').DataTable();
        $("#reportTable_filter>label").attr("style","display:flex;");
    }
    else {
        $("#reportTable").hide();
        $(".empty").css("display", "flex");
    }
});

// View Mode
function viewMode(thisval) {
    let projectCode = $(thisval).parent().parent().find(".projectCode").text();
    let invoiceNumber = $(thisval).parent().parent().find(".invoiceNumber").text();
    let amount = $(thisval).parent().parent().find(".amount").text();
    let status = $(thisval).parent().parent().find(".status").text();

    $("#projectCode").val(projectCode);
    $("#invoiceNumber").val(invoiceNumber);
    $("#amount").val(amount);
    $("#status").val(status);
    
}

// Edit Mode
function editMode(thisval) {
    $(thisval).after(`<i id="save" class="fa-solid fa-floppy-disk" onclick="save(this)"></i>`);
    $(thisval).attr("style", "display:none;");
    let selectedRow = $(thisval).parent().parent();
    selectedRow.children().not(".icon").attr("contenteditable", "true");
}
//Save Function
function save(thisval) {
    let projectCode = $(thisval).parent().parent().find(".projectCode").text();
    let invoiceNumber = $(thisval).parent().parent().find(".invoiceNumber").text();
    let amount = $(thisval).parent().parent().find(".amount").text();
    let status = $(thisval).parent().parent().find(".status").text();


    // Clients POST API
    var Update = {
        "tableName": "AllInvoices",
        "crudOperation": "UPDATE",
        "columnData": [
            {
                "columnName": "projectCode",
                "columnValue": projectCode
            },
            {
                "columnName": "invoiceNumber",
                "columnValue": invoiceNumber
            },
            {
                "columnName": "amount",
                "columnValue": amount
            },
            {
                "columnName": "status",
                "columnValue": status
            }
        ]
    }
    recordOperation(Update);

    $(thisval).after(`<i id="edit" class="fa-solid fa-pen-to-square" onclick="clientEditMode(this)"></i>`);
    $(thisval).attr("style", "display:none;");
    let selectedRow = $(thisval).parent().parent();
    selectedRow.children().not(".icon").attr("contenteditable", "false");
}

// Delete Mode
function deleteMode(thisval) {
    let delRec = $(thisval).parent().parent().find(".projectCode").text();
    
    var Delete = {
        "tableName": "AllInvoices",
        "crudOperation": "DELETE",
        "columnData": [
            {
                "columnName": "projectCode",
                "columnValue": delRec
            }
        ]
    }
    recordOperation(Delete);
}

// Add Column API
$("#addColumn").click(function(){
    var tableName = "AllInvoices"
    var columnName = $("#columnName").val();
    var columnType = $("#columnType").val();

    var columnObj = {
        "tableNameForModification": tableName,
        "columnName": columnName,
        "columnType": columnType
      }
      tableColumnModify(columnObj);
});


// $("#plus>i").click(function(){
//     window.open("http://localhost:90/form/clients.html","_self");
// });

// $("#addRec").click(function(){
//     window.open("http://localhost:90/form/clients.html","_self")
// });