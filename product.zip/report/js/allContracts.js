
// function getAllAssignmentNature(data) { } function getAllClients(data) { } function getAllEmployees(data) { } function getAllProjects(data) { }







var getData = {
    "tableName": "AllContracts",
    "crudOperation": "VIEW",
    "columnData": null
}

recordGetPost(getData).then(function(res){
    if (res.length > 0) {
        $("#reportTable").show(400);
        $(".empty").hide();

        var sno = 0;
        for (let i = 0; i < res.length; i++) {
            sno += 1;
            const rows = res[i];
            $("#reportTable tbody").append(`<tr onmouseover="rowMouseOver(this)" onmouseleave="rowMouseLeave(this)">
            <td class="icon"><i id="delete" class="fa-solid fa-trash" onclick="deleteMode(this)"></i><i id="edit" class="fa-solid fa-pen-to-square" onclick="editMode(this)"></i><i id="view" data-bs-toggle="modal" data-bs-target="#exampleModal" class="fa-sharp fa-solid fa-eye" onclick="viewMode(this)"></i></td>
            <td class="clientName">${rows.entity}</td>
            <td class="clientName">${rows.clientName}</td>
            <td class="contractName">${rows.contractName}</td>
            <td class="assignNature">${rows.assignmentNature}</td>
            <td class="type">${rows.type}</td>
            <td class="frequency">${rows.frequency}</td>
            <td class="startDate">${rows.contractStartDate}</td>
            <td class="endDate">${rows.contractEndDate}</td>
            <td class="amount">${rows.amount}</td>
            <td class="personResponsible">${rows.personResponsible}</td>
            <td class="contractID">${rows.urn}</td>
            </tr>`);
        }
        $('#reportTable').DataTable();
        $("#reportTable_filter>label").attr("style","display:flex;");
    }
    else {
        $("#reportTable").hide();
        $(".empty").css("display", "flex");
    }
});

// View Mode
function viewMode(thisval) {

    let entity = $(thisval).parent().parent().find(".entity").text();
    let clientName = $(thisval).parent().parent().find(".clientName").text();
    let contractName = $(thisval).parent().parent().find(".contractName").text();
    let assignNature = $(thisval).parent().parent().find(".assignNature").text();
    let type = $(thisval).parent().parent().find(".type").text();
    let frequency = $(thisval).parent().parent().find(".frequency").text();
    let startDate = $(thisval).parent().parent().find(".startDate").text();
    let endDate = $(thisval).parent().parent().find(".endDate").text();
    let amount = $(thisval).parent().parent().find(".amount").text();
    let personResponsible = $(thisval).parent().parent().find(".personResponsible").text();
    let contractID = $(thisval).parent().parent().find(".contractID").text();

    $("#entity").val(entity);
    $("#contractName").val(contractName);
    $("#clientName").append(`<option value="${clientName}">${clientName}</option>`);
    $("#nature").append(`<option value="${assignNature}">${assignNature}</option>`);
    $("#type").val(type);
    $("#frequency").val(frequency);
    $("#fromDate").val(startDate);
    $("#toDate").val(endDate);
    $("#amount").val(amount);
    $("#personRes").append(`<option value="${personResponsible}">${personResponsible}</option>`);
    $("#contractID").val(contractID);
    
}

// Edit Mode
function editMode(thisval) {
    $(thisval).after(`<i id="save" class="fa-solid fa-floppy-disk" onclick="save(this)"></i>`);
    $(thisval).attr("style", "display:none;");
    let selectedRow = $(thisval).parent().parent();
    selectedRow.children().not(".icon").attr("contenteditable", "true");
}
//Save Function
function save(thisval) {

    let entity = $(thisval).parent().parent().find(".entity").text();
    let clientName = $(thisval).parent().parent().find(".clientName").text();
    let contractName = $(thisval).parent().parent().find(".contractName").text();
    let assignNature = $(thisval).parent().parent().find(".assignNature").text();
    let type = $(thisval).parent().parent().find(".type").text();
    let frequency = $(thisval).parent().parent().find(".frequency").text();
    let startDate = $(thisval).parent().parent().find(".startDate").text();
    let endDate = $(thisval).parent().parent().find(".endDate").text();
    let amount = $(thisval).parent().parent().find(".amount").text();
    let personResponsible = $(thisval).parent().parent().find(".personResponsible").text();
    let contractID = $(thisval).parent().parent().find(".contractID").text();


    // Contracts POST API
    var Update = {
        "tableName": "AllContracts",
        "crudOperation": "UPDATE",
        "columnData": [
                {
                "columnName": "urn",
                "columnValue": contractID
                },
                {
                    "columnName": "entity",
                    "columnValue": entity
                },
                {
                    "columnName": "contractName",
                    "columnValue": contractName
                },
                {
                    "columnName": "clientName",
                    "columnValue": clientName
                },
                {
                    "columnName": "assignmentNature",
                    "columnValue": assignNature
                },
                {
                    "columnName": "type",
                    "columnValue": type
                },
                {
                    "columnName": "frequency",
                    "columnValue": frequency
                },
                {
                    "columnName": "contractStartDate",
                    "columnValue": startDate
                },
                {
                    "columnName": "contractEndDate",
                    "columnValue": endDate
                },
                {
                    "columnName": "amount",
                    "columnValue": amount
                },
                {
                    "columnName": "personResponsible",
                    "columnValue": personResponsible
                }
        ]
    }
    recordOperation(Update);

    $(thisval).after(`<i id="edit" class="fa-solid fa-pen-to-square" onclick="clientEditMode(this)"></i>`);
    $(thisval).attr("style", "display:none;");
    let selectedRow = $(thisval).parent().parent();
    selectedRow.children().not(".icon").attr("contenteditable", "false");
}

// Delete Mode
function deleteMode(thisval) {
    let delRec = $(thisval).parent().parent().find(".contractID").text();
    
    var Delete = {
        "tableName": "AllContracts",
        "crudOperation": "DELETE",
        "columnData": [
            {
                "columnName": "urn",
                "columnValue": delRec
            }
        ]
    }
    recordOperation(Delete);
}

// Add Column API
$("#addColumn").click(function(){
    var tableName = "AllContracts"
    var columnName = $("#columnName").val();
    var columnType = $("#columnType").val();

    var columnObj = {
        "tableNameForModification": tableName,
        "columnName": columnName,
        "columnType": columnType
      }
      tableColumnModify(columnObj);
});


$("#plus>i").click(function(){
    window.open("http://localhost:90/form/contracts.html","_self");
});

$("#addRec").click(function(){
    window.open("http://localhost:90/form/contracts.html","_self")
});
