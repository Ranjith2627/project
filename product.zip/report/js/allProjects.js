
var getData = {
    "tableName": "AllProjects",
    "crudOperation": "VIEW",
    "columnData": null
}

recordGetPost(getData).then(function(res){
    if (res.length > 0) {
        $("#reportTable").show(400);
        $(".empty").hide();

        var sno = 0;
        for (let i = 0; i < res.length; i++) {
            sno += 1;
            const rows = res[i];
            $("#reportTable tbody").append(`<tr onmouseover="rowMouseOver(this)" onmouseleave="rowMouseLeave(this)">
            <td class="icon"><i id="delete" class="fa-solid fa-trash" onclick="deleteMode(this)"></i><i id="edit" class="fa-solid fa-pen-to-square" onclick="editMode(this)"></i><i id="view" data-bs-toggle="modal" data-bs-target="#exampleModal" class="fa-sharp fa-solid fa-eye" onclick="viewMode(this)"></i></td>
            <td class="projectCode">${rows.projectCode}</td>
            <td class="contractId">${rows.urn}</td>
            <td class="clientName">${rows.clientName}</td>
            <td class="contractName">${rows.projectDescription}</td>
            <td class="assignNature">${rows.assignmentNature}</td>
            <td class="quarter">${rows.quarter}</td>
            <td class="amount">${rows.amount}</td>
            <td class="personResponsible">${rows.personResponsible}</td>
            <td class="status">${rows.status}</td>
            </tr>`);
        }
        $('#reportTable').DataTable();
        $("#reportTable_filter>label").attr("style","display:flex;");
    }
    else {
        $("#reportTable").hide();
        $(".empty").css("display", "flex");
    }
});

// View Mode
function viewMode(thisval) {
    let projectCode = $(thisval).parent().parent().find(".projectCode").text();
    let contractId = $(thisval).parent().parent().find(".contractId").text();
    let clientName = $(thisval).parent().parent().find(".clientName").text();
    let contractName = $(thisval).parent().parent().find(".contractName").text();
    let assignNature = $(thisval).parent().parent().find(".assignNature").text();
    let quarter = $(thisval).parent().parent().find(".quarter").text();
    let amount = $(thisval).parent().parent().find(".amount").text();
    let personResponsible = $(thisval).parent().parent().find(".personResponsible").text();
    let status = $(thisval).parent().parent().find(".status").text();

    $("#projectCode").val(projectCode);
    $("#contractId").val(contractId);
    $("#clientName").val(clientName);
    $("#contractName").val(contractName);
    $("#assignNature").val(assignNature);
    $("#quarter").val(quarter);
    $("#amount").val(amount);
    $("#personResponsible").val(personResponsible);
    $("#status").val(status);
    
}

// Edit Mode
function editMode(thisval) {
    $(thisval).after(`<i id="save" class="fa-solid fa-floppy-disk" onclick="save(this)"></i>`);
    $(thisval).attr("style", "display:none;");
    let selectedRow = $(thisval).parent().parent();
    selectedRow.children().not(".icon").attr("contenteditable", "true");
}
//Save Function
function save(thisval) {
    let projectCode = $(thisval).parent().parent().find(".projectCode").text();
    let contractId = $(thisval).parent().parent().find(".contractId").text();
    let clientName = $(thisval).parent().parent().find(".clientName").text();
    let contractName = $(thisval).parent().parent().find(".contractName").text();
    let assignNature = $(thisval).parent().parent().find(".assignNature").text();
    let quarter = $(thisval).parent().parent().find(".quarter").text();
    let amount = $(thisval).parent().parent().find(".amount").text();
    let personResponsible = $(thisval).parent().parent().find(".personResponsible").text();
    let status = $(thisval).parent().parent().find(".status").text();


    // Clients POST API
    var Update = {
        "tableName": "AllProjects",
        "crudOperation": "UPDATE",
        "columnData": [
            {
                "columnName": "projectCode",
                "columnValue": projectCode
            },
            {
                "columnName": "urn",
                "columnValue": contractId
            },
            {
                "columnName": "clientName",
                "columnValue": clientName
            },
            {
                "columnName": "assignmentNature",
                "columnValue": assignNature
            },
            {
                "columnName": "quarter",
                "columnValue": quarter
            },
            {
                "columnName": "projectDescription",
                "columnValue": contractName
            },
            {
                "columnName": "amount",
                "columnValue": amount
            },
            {
                "columnName": "personResponsible",
                "columnValue": personResponsible
            },
            {
                "columnName": "status",
                "columnValue": status
            }
        ]
    }
    recordOperation(Update);

    $(thisval).after(`<i id="edit" class="fa-solid fa-pen-to-square" onclick="clientEditMode(this)"></i>`);
    $(thisval).attr("style", "display:none;");
    let selectedRow = $(thisval).parent().parent();
    selectedRow.children().not(".icon").attr("contenteditable", "false");
}

// Delete Mode
function deleteMode(thisval) {
    let delRec = $(thisval).parent().parent().find(".projectCode").text();
    
    var Delete = {
        "tableName": "AllProjects",
        "crudOperation": "DELETE",
        "columnData": [
            {
                "columnName": "projectCode",
                "columnValue": delRec
            }
        ]
    }
    recordOperation(Delete);
}

// Add Column API
$("#addColumn").click(function(){
    var tableName = "AllProjects"
    var columnName = $("#columnName").val();
    var columnType = $("#columnType").val();

    var columnObj = {
        "tableNameForModification": tableName,
        "columnName": columnName,
        "columnType": columnType
      }
      tableColumnModify(columnObj);
});


// $("#plus>i").click(function(){
//     window.open("http://localhost:90/form/clients.html","_self");
// });

// $("#addRec").click(function(){
//     window.open("http://localhost:90/form/clients.html","_self")
// });