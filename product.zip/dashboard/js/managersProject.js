
var url = (window.location.href).toString().split("?");
var pr = url[1].split("=")
var currentProject = pr[1].replaceAll("%20", " ");
$("#crPrj").text(currentProject);


var getData = {
    "tableName": "AllProjects",
    "crudOperation": "VIEW",
    "columnData": [
        {
            "columnName": "projectCode",
            "columnValue": currentProject
        }
    ]
}
recordGetPost(getData).then(function (res) {
    var row = res[0];

    var getMilestone = {
        "tableName": "Milestones",
        "crudOperation": "VIEW",
        "columnData": [
            {
                "columnName": "assignmentNature",
                "columnValue": row.assignmentNature
            }
        ]
    }

    recordGetPost(getMilestone).then(function (milesRes) {
        console.log(milesRes);
        count = 0;
        for (let j = 0; j < milesRes.length; j++) {
            let mileRows = milesRes[j];
            count += 1;
            $("#milestone").append(`
            <li class="list-inline-item event-list">
            <div class="px-4">
                <div class="event-date bg-soft-primary text-primary">Week ${count}</div>
                <h5 class="font-size-16">${mileRows.milestones}</h5>
                <!-- <p class="text-muted">It will be as simple as occidental in fact it will be Occidental Cambridge friend</p> -->
                <div>
                    <button id="completed1" class="btn btn-primary btn-sm" onclick=progressLevel(this)>Completed</button>
                    <input type="file"
                        style="width:80%;cursor:pointer;margin:4% 0% 0% 20%;font-size:12px;">
                </div>
            </div>
        </li>
            `);
        }
    });

    $(".projectDetails").append(`
        <table class="table">
            <tr><th>Client Name</th><td>${row.clientName}</td></tr>
            <tr><th>Assignment Nature</th><td>${row.assignmentNature}</td></tr>
            <tr><th>Project Code</th><td>${row.projectCode}</td></tr>
            <tr><th>Project Description</th><td>${row.projectDescription}</td></tr>
        </table>
    `);
});

$("#newPlan").click(function () {
    $(this).attr("href", `http://localhost:90/dashboard/managersPlan.html?project=${currentProject}`)
});

$("#completed1").click(function () {
    $(".progress").attr("style", "width:12.1%;")
});
$("#completed2").click(function () {
    $(".progress").attr("style", "width:36.55%;")
});
$("#completed3").click(function () {
    $(".progress").attr("style", "width:60.8%;")
});
$("#completed4").click(function () {
    $(".progress").attr("style", "width:85.15%;")
});

// function progressLevel(thisval){
//     if(thisval == "completed1"){
//         $(".progress").attr("style", "width:12.1%;");
//     }
//     if(thisval == "completed2"){
//         $(".progress").attr("style", "width:12.1%;");
//     }
//     if(thisval == "completed3"){
//         $(".progress").attr("style", "width:12.1%;");
//     }
//     if(thisval == "completed1"){
//         $(".progress").attr("style", "width:12.1%;");
//     }
// }