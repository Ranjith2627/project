
    // var url = (window.location.href).toString().split("?");
    //     paramsList = url[1].split("=");
    //     var params = [];
    //     // for(let i=0;i<paramsList[1].length;i++){
    //     //     var value = paramsList[1][i].split(",");
    //     //     var key = value[0];
    //     //     params.push(key);
    //     // }

    var getData = {
        "tableName": "AllProjects",
        "crudOperation": "VIEW",
        "columnData": null
    }
    recordGetPost(getData).then(function(res){
        for(let i=0;i<res.length;i++){
            const rows = res[i];

            $("#crntProjects").append(`               
            <a class="card shadow p-3" href="http://localhost:90/dashboard/managersProject.html?project=${rows.projectCode}" target="_self"><div>${rows.projectDescription} - ${rows.projectCode}</div></a>
            `);
        }
    });


    


        $("#managerSmt").click(function(){
            var compPrj = document.querySelectorAll("#totalProjectComplete");
            var compPrjList = [];
            for(let i=0;i<compPrj.length;i++){
                if(compPrj[i].innerHTML.toString() == "✔"){
                    var val = (compPrj[i].previousElementSibling.previousElementSibling.children[0].innerHTML);
                    compPrjList.push(val);
                }
            }
            window.open("http://localhost:90/dashboard/accounts.html?prj="+compPrjList);
        });
        



function projectCompletion(thisval){
    window.alert("Please confirm for completion");
    $(thisval).parent().hide(400);
    $(thisval).html("✔");

    let compPrj = document.querySelectorAll("#totalProjectComplete");
    var co = $("#compCount").html();
    for(let i=0;i<compPrj.length;i++){
        if(compPrj[i].innerHTML.toString() == "✔"){
            $("#compCount").html(parseInt(co) + 1);
        }
    }
    
}





