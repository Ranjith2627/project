var url = (window.location.href).toString().split("?");
var pr = url[1].split("=")
var currentProject = pr[1].replaceAll("%20", " ");
$("#crPrj").text(currentProject);

$("#newPlan").click(function(){
    $(this).attr("href",`http://localhost:90/dashboard/managersPlan.html?project=${currentProject}`)
});

rowCount = 0;
function addNewRow() {
    rowCount += 1;
    $("#planTable").append(`<tr id="r${rowCount}" style="border-bottom:1px solid rgba(0,0,0,0.09);">
    <td>${rowCount}</td>
    <td contenteditable="true"></td>
    <td><select class="employee"><option>Select</option></select></td>
    </tr>`);
    employeeList(`r${rowCount}`);
}

function employeeList(row){
    var getData = {
        "tableName":"AllEmployees",
        "crudOperation":"VIEW",
        "columnData":null
    }
    recordGetPost(getData).then(function(res){
        for(let i=0;i<res.length;i++){
            var rows = res[i];
            $(`#${row}`).find(".employee").append(`<option value="${rows.employeeName}">${rows.employeeName}</option>`);
        }
    });
}
