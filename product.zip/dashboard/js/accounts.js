var getData = {
    "tableName":"AllProjects",
    "crudOperation":"VIEW",
    "columnData":null,
}
recordGetPost(getData).then(function(res){
    // console.log(res);
    notification = 0;
    for(let i=0;i<res.length;i++){
        notification += 1;
        var rows = res[i];
        $("#ubProjects").append(`<div><a class="collapse-item" href="http://localhost:90/template/invoiceTemplate.html?invPrj=${rows.projectCode}" target="_self">${rows.projectDescription} - ${rows.projectCode}</a></div>`);
        $("#ubNotify").text(notification);

        $("#pendInvoice").append(`<div><a class="collapse-item" href="http://localhost:90/template/invoiceTemplate.html?invPrj=${rows.projectCode}" target="_self">${rows.projectDescription} - ${rows.projectCode}</a></div>`);
        $("#penNotify").text(notification);

        $("#compInvoice").append(`<div><a class="collapse-item" href="http://localhost:90/template/invoiceTemplate.html?invPrj=${rows.projectCode}" target="_self">${rows.projectDescription} - ${rows.projectCode}</a></div>`);
        $("#compNotify").text(notification);
    }
});

