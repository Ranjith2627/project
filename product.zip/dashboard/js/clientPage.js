
// Get Projects Api
var projectsObj = {
    "tableName":"AllProjects",
    "crudOperation":"VIEW",
    "columnData":null,
}
recordGetPost(projectsObj).then(function(res){
    // console.log(res);
    notification = 0;
    for(let i=0;i<res.length;i++){
        notification += 1;
        var rows = res[i];

        $("#pendInvoice").append(`<div><a class="collapse-item" href="" target="_self">${rows.projectDescription} - ${rows.projectCode}</a></div>`);
        $("#penNotify").text(notification);
//http://localhost:90/template/invoiceTemplate.html?invPrj=${rows.projectCode}
        $("#compInvoice").append(`<div><a class="collapse-item" href="" target="_self">${rows.projectDescription} - ${rows.projectCode}</a></div>`);
        $("#compNotify").text(notification);
    }
});


// Get Propsal Api
var filesObj = {
    "tableName":"AllFiles",
    "crudOperation":"VIEW",
    "columnData":null,
}
recordGetPost(filesObj).then(function(res){
    rows = res[0];
    $("#proposal").append(`${rows.proposal}`);
});