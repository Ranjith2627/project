var appId = 100000;

const params = new URLSearchParams(window.location.search);
if(params.has('status') == true){
    var clientStatus = params.get('status');
    console.log(clientStatus);
    $("#status").val(clientStatus);
}

var getData = {
    "tableName": "ClientMaster",
    "crudOperation": "VIEW",
    "columnData": null
}
recordGetPost(getData).then(function(res){
    var clientCode = res.length + 1;
    $("#clientCode").val(clientCode);
    $("#appID").val(res.length + 1 + appId);
}); // Function recordGetPost End

$("#formSubmit").click(function () {
    let clientName = $("#clientName").val();
    let clientCode = $("#clientCode").val();
    let email = $("#email").val();
    let mobile = $("#mobile").val();
    let clientGroup = $("#clientGroup").val();
    let status = $("#status").val();

    var insert = {
        "tableName": "ClientMaster",
        "crudOperation": "INSERT",
        "columnData": [
            {
            "columnName": "clientName",
            "columnValue": clientName
            },
            {
                "columnName": "clientCode",
                "columnValue": clientCode
            },
            {
                "columnName": "email",
                "columnValue": email
            },
            {
                "columnName": "mobile",
                "columnValue": mobile
            },
            {
                "columnName": "clientGroup",
                "columnValue": clientGroup
            },
            {
            "columnName": "status",
            "columnValue": status
            }
        ]
    }
    recordOperation(insert);
});