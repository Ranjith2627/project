var appId = 100000;

var assignNature = {
    "tableName": "AssignmentNature",
    "crudOperation": "VIEW",
    "columnData": null
}
recordGetPost(assignNature).then(function (res) {
    for (let i = 0; i < res.length; i++) {
        $("#assignNature").append(`<option value="${res[i].assignmentNature}">${res[i].assignmentNature}</option>`);
    }
});

var getData = {
    "tableName": "Milestones",
    "crudOperation": "VIEW",
    "columnData": null
}
recordGetPost(getData).then(function (res) {
    console.log(res);
    $("#appID").val(res.length + 1 + appId);
}); // Function recordGetPost End

$("#formSubmit").click(function () {
    let assignmentNature = $("#assignNature").val();
    let milestoneNumber = $("#milestoneNumber").val();
    let milestones = $("#milestones").val();

    var insert = {
        "tableName": "Milestones",
        "crudOperation": "INSERT",
        "columnData": [
            {
                "columnName": "assignmentNature",
                "columnValue": assignmentNature
            },
            {
                "columnName": "milestoneNumber",
                "columnValue": milestoneNumber
            },
            {
                "columnName": "milestones",
                "columnValue": milestones
            }
        ]
    }
    recordOperation(insert);
});