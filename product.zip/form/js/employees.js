var appId = 100000;

var dept = {
    "tableName": "AllDepartments",
    "crudOperation": "VIEW",
    "columnData": null
}
recordGetPost(dept).then(function (res) {
    for(let i=0;i<res.length;i++){
        $("#department").append(`<option value="${res[i].departmentName}">${res[i].departmentName}</option>`);
    }
});


var getData = {
    "tableName": "AllEmployees",
    "crudOperation": "VIEW",
    "columnData": null
}
recordGetPost(getData).then(function (res) {
    var employeeCode = res.length + 1;
    $("#employeeCode").val(employeeCode);
    
}); // Function recordGetPost End

$("#formSubmit").click(function () {
    let employeeCode = $("#employeeCode").val();
    let employeeName = $("#employeeName").val();
    let department = $("#department").val();
    let designation = $("#designation").val();
    let doj = $("#dateOfJoining").val();
    let dor = $("#dateOfResignation").val();

    console.log(doj);
    console.log(dor);

    var insert = {
        "tableName": "AllEmployees",
        "crudOperation": "INSERT",
        "columnData": [
            {
                "columnName": "employeeCode",
                "columnValue": employeeCode
            },
            {
                "columnName": "employeeName",
                "columnValue": employeeName
            },
            {
                "columnName": "department",
                "columnValue": department
            },
            {
                "columnName": "designation",
                "columnValue": designation
            },
            {
                "columnName": "dateOfJoining",
                "columnValue": doj
            },
            {
                "columnName": "dateOfResignation",
                "columnValue": dor
            }
        ]
    }
    recordOperation(insert);
});