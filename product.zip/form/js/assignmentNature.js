var appId = 100000;

// Get All Assignment Nature API
var getData = {
    "tableName": "AssignmentNature",
    "crudOperation": "VIEW",
    "columnData": null
}
recordGetPost(getData).then(function (res) {
    var clientCode = res.length + 1;
    $("#clientCode").val(clientCode);
    $("#appID").val(res.length + 1 + appId);
}); // Function recordGetPost End

// ***************** Save and New *****************
$("#formSubmit").click(function () {
    let assignmentNature = $("#assignNature").val();
    let type = $("#type").val();
    let frequency = $("#frequency").val();
    let standardPrice = $("#standardPrice").val();
    let multiplier = $("#multiplier").val();
    let statutoryAssign = $("#statutoryAssignment").val();

    var insert = {
        "tableName": "AssignmentNature",
        "crudOperation": "INSERT",
        "columnData": [
            {
                "columnName": "assignmentNature",
                "columnValue": assignmentNature
            },
            {
                "columnName": "type",
                "columnValue": type
            },
            {
                "columnName": "frequency",
                "columnValue": frequency
            },
            {
                "columnName": "standardPrice",
                "columnValue": standardPrice
            },
            {
                "columnName": "multiplier", 
                "columnValue": multiplier
            },
            {
                "columnName": "isStatutoryAssignment",
                "columnValue": statutoryAssign
            }
        ]
    }
    recordOperation(insert);
});

// ***************** Save and Close *****************
$("#formSaveAndClose").click(function () {
    let assignmentNature = $("#assignNature").val();
    let type = $("#type").val();
    let frequency = $("#frequency").val();
    let standardPrice = $("#standardPrice").val();
    let multiplier = $("#multiplier").val();
    let statutoryAssign = $("#statutoryAssignment").val();

    console.log(frequency);

    var insert = {
        "tableName": "AssignmentNature",
        "crudOperation": "INSERT",
        "columnData": [
            {
                "columnName": "assignmentNature",
                "columnValue": assignmentNature
            },
            {
                "columnName": "type",
                "columnValue": type
            },
            {
                "columnName": "frequency",
                "columnValue": frequency
            },
            {
                "columnName": "standardPrice",
                "columnValue": standardPrice
            },
            {
                "columnName": "multiplier", 
                "columnValue": multiplier
            },
            {
                "columnName": "isStatutoryAssignment",
                "columnValue": statutoryAssign
            }
        ]
    }
    recordOperation(insert);

    window.history.go(-1);
});


//****************************************************** Workflows ******************************************************************

// 1.User Input Of Field
window.onload = function(){
    fequencyHideShow();
    multiplierUpdate();
}

$("#type").change(function () {
    fequencyHideShow();
});
$("#frequency").change(function () {
    multiplierUpdate();
});

function fequencyHideShow(){
    const type = $("#type").val();
    if(type == "Non Recurring"){
        $("#freqDiv").hide();
        $("#multiplierDiv").hide();
        $("#frequency").val("No");
        $("#multiplier").val(0);
    }
    else{
        $("#freqDiv").attr("style","display:flex;");
        $("#multiplierDiv").attr("style","display:flex;");
    }
}

function multiplierUpdate(){
    const frequency = $("#frequency").val();
    if(frequency == "Monthly"){
        $("#multiplier").val(12);
    }
    if(frequency == "Quarterly"){
        $("#multiplier").val(4);
    }
    if(frequency == "Half-yearly"){
        $("#multiplier").val(2);
    }
    if(frequency == "Yearly"){
        $("#multiplier").val(1);
    }
}