// function getAllProjects(data){} function getAllEmployees(data){}
var client = {
    "tableName": "ClientMaster",
    "crudOperation": "VIEW",
    "columnData": null
}
recordGetPost(client).then(function (res) {
    for (let i = 0; i < res.length; i++) {
        $("#clientName").append(`<option value="${res[i].clientName}">${res[i].clientName}</option>`);
    }
});

var assignNature = {
    "tableName": "AssignmentNature",
    "crudOperation": "VIEW",
    "columnData": null
}
recordGetPost(assignNature).then(function (res) {
    for (let i = 0; i < res.length; i++) {
        $("#assignNature").append(`<option value="${res[i].assignmentNature}">${res[i].assignmentNature}</option>`);
    }
    typeFrequencyUpdate();
});
var managerResponsible = {
    "tableName": "AllDepartments",
    "crudOperation": "VIEW",
    "columnData": null
}
recordGetPost(managerResponsible).then(function (res) {
    for (let i = 0; i < res.length; i++) {
        $("#managerResponsible").append(`<option value="${res[i].departmentHead}">${res[i].departmentHead}</option>`);
    }
});

var personResponsible = {
    "tableName": "AllEmployees",
    "crudOperation": "VIEW",
    "columnData": null
}
recordGetPost(personResponsible).then(function (res) {
    for (let i = 0; i < res.length; i++) {
        $(".personRes").append(`<option value="${res[i].employeeName}">${res[i].employeeName}</option>`);
    }
});


var appId = 100000;

var getData = {
    "tableName": "AllContracts",
    "crudOperation": "VIEW",
    "columnData": null
}
recordGetPost(getData).then(function (res) {
    $("#contractID").val(res.length + 1 + appId);
}); // Function recordGetPost End


$("#formSubmit").click(function () {

    let clientName = $("#clientName").val();
    let entity = document.querySelector('input[name="entity"]:checked').value;
    let contractName = $("#contractName").val();
    let assignNature = $("#assignNature").val();
    let type = $("#type").val();
    let frequency = $("#frequency").val();
    let startDate = $("#contractStartDate").val();
    let endDate = $("#contractEndDate").val();
    let amount = $("#amount").val();
    let personResponsible = $("#managerResponsible").val();
    let contractID = $("#contractID").val();


    var insert = {
        "tableName": "AllContracts",
        "crudOperation": "INSERT",
        "columnData": [
            {
                "columnName": "urn",
                "columnValue": contractID
            },
            {
                "columnName": "entity",
                "columnValue": entity
            },
            {
                "columnName": "contractName",
                "columnValue": contractName
            },
            {
                "columnName": "clientName",
                "columnValue": clientName
            },
            {
                "columnName": "assignmentNature",
                "columnValue": assignNature
            },
            {
                "columnName": "type",
                "columnValue": type
            },
            {
                "columnName": "frequency",
                "columnValue": frequency
            },
            {
                "columnName": "contractStartDate",
                "columnValue": startDate
            },
            {
                "columnName": "contractEndDate",
                "columnValue": endDate
            },
            {
                "columnName": "amount",
                "columnValue": amount
            },
            {
                "columnName": "personResponsible",
                "columnValue": personResponsible
            }
        ]
    }
    recordOperation(insert);
    var check = {
        "tableName": "AllContracts",
        "crudOperation": "VIEW",
        "columnData": [
            {
                "columnName": "urn",
                "columnValue": contractID
            }
        ]
    }
    setTimeout(function () {
        recordGetPost(check).then(function (res) {
            var rows = res[0];
            var prjstart = parseInt(res[0].urn.toString() + "000");
            if (res.length == 1 && rows.type == "Recurring") {

                var startdate = new Date(startDate)
                var $enddate = new Date(endDate)
                var calculateMonths = ($enddate.getMonth() - startdate.getMonth()) + 1 + (12 * ($enddate.getFullYear() - startdate.getFullYear()));
                if (rows.frequency == "Monthly") {
                    var months = calculateMonths;
                }
                if (rows.frequency == "Quarterly") {
                    var months = parseInt(calculateMonths / 4);
                }
                if (rows.frequency == "Half-yearly") {
                    var months = parseInt(calculateMonths / 6);
                }
                if (rows.frequency == "Yearly") {
                    var months = parseInt(calculateMonths / 12);
                }

                var prevMonth = startdate.add(-1).month();
                let prjCode = 0;

                for (let i = 0; i < months; i++) {
                    let dateFormat = document.querySelector('input[name="dateFormat"]:checked').value;
                    var currentMon = prevMonth.add(1).month();
                    var mon = currentMon.getMonth();
                    if (dateFormat == "Calender Year") {
                        if (mon == 0 || mon == 1 || mon == 2) {
                            var quarter = "Q1";
                        }
                        if (mon == 3 || mon == 4 || mon == 5) {
                            var quarter = "Q2";
                        }
                        if (mon == 6 || mon == 7 || mon == 8) {
                            var quarter = "Q3";
                        }
                        if (mon == 9 || mon == 10 || mon == 11) {
                            var quarter = "Q4";
                        }
                    }
                    if (dateFormat == "Financial Year") {
                        if (mon == 0 || mon == 1 || mon == 2) {
                            var quarter = "Q4";
                        }
                        if (mon == 3 || mon == 4 || mon == 5) {
                            var quarter = "Q1";
                        }
                        if (mon == 6 || mon == 7 || mon == 8) {
                            var quarter = "Q2";
                        }
                        if (mon == 9 || mon == 10 || mon == 11) {
                            var quarter = "Q3";
                        }
                    }
                    prjCode += 1;
                    let projectInsert = {
                        "tableName": "AllProjects",
                        "crudOperation": "INSERT",
                        "columnData": [
                            {
                                "columnName": "urn",
                                "columnValue": contractID
                            },
                            {
                                "columnName": "projectCode",
                                "columnValue": prjCode + prjstart
                            },
                            {
                                "columnName": "clientName",
                                "columnValue": clientName
                            },
                            {
                                "columnName": "assignmentNature",
                                "columnValue": assignNature
                            },
                            {
                                "columnName": "quarter",
                                "columnValue": quarter
                            },
                            {
                                "columnName": "projectDescription",
                                "columnValue": contractName
                            },
                            {
                                "columnName": "amount",
                                "columnValue": amount
                            },
                            {
                                "columnName": "personResponsible",
                                "columnValue": personResponsible
                            }
                        ]
                    }
                    recordOperation(projectInsert);
                }
            }

            if (res.length == 1 && rows.type == "Non Recurring") {
                let prjCode = prjstart + 1;
                let projectInsert = {
                    "tableName": "AllProjects",
                    "crudOperation": "INSERT",
                    "columnData": [
                        {
                            "columnName": "urn",
                            "columnValue": contractID
                        },
                        {
                            "columnName": "projectCode",
                            "columnValue": prjCode
                        },
                        {
                            "columnName": "clientName",
                            "columnValue": clientName
                        },
                        {
                            "columnName": "assignmentNature",
                            "columnValue": assignNature
                        },
                        {
                            "columnName": "projectDescription",
                            "columnValue": contractName
                        },
                        {
                            "columnName": "amount",
                            "columnValue": amount
                        },
                        {
                            "columnName": "personResponsible",
                            "columnValue": personResponsible
                        }
                    ]
                }
                recordOperation(projectInsert);

                // Invoice Creation
                var invoiceData = {
                    "tableName": "AllInvoices",
                    "crudOperation": "VIEW",
                    "columnData": null
                }
                
                recordGetPost(invoiceData).then(function (res) {
                    var date = new Date();
                    var mo = date.toLocaleString("default",{'month':'short'});
                    var yr = date.getFullYear().toString().substr(-2);
                    var invoiceNumber = 800000 + res.length;
                
                let advance = $(".advance").children();

                for (let k = 0; k < advance.length; k++) {
                    var invoiceAmount = $(advance[k]).parent().parent().find(".percentAmnt").children().val();
                    invoiceNumber += 1;
                    if (advance[k].checked == true) {
                        var invoiceStatus = "Generated";
                    }
                    else{
                        var invoiceStatus = "Pending";
                    }

                    let invoiceInsert = {
                        "tableName": "AllInvoices",
                        "crudOperation": "INSERT",
                        "columnData": [
                            {
                                "columnName": "invoiceNumber",
                                "columnValue": mo +"-"+ invoiceNumber +"-"+ yr
                            },
                            {
                                "columnName": "projectCode",
                                "columnValue": prjCode
                            },
                            {
                                "columnName": "amount",
                                "columnValue": invoiceAmount
                            },
                            {
                                "columnName": "status",
                                "columnValue": invoiceStatus
                            }
                        ]
                    }
                    recordOperation(invoiceInsert);
                }
            });
            }
        });
    }, "1000");
});


//****************************************************** Workflows ******************************************************************

// 1.User Input Of Field
window.onload = function () {
    milestoneTableCreation();
}

var input = $(".forms>form");
$("#assignNature").change(function () {
    typeFrequencyUpdate();
    milestoneTableCreation();
});

$("#relevantStartDate").change(function () {
    relevantEndDateUpdate();
    relevantYearUpdate();
    quarterUpdate();
});
$("#frequency").change(function () {
    relevantEndDateUpdate();
});
$("input[name='dateFormat']").change(function () {
    relevantYearUpdate();
    quarterUpdate();
});

function typeFrequencyUpdate() {
    let inputAssignNature = $("#assignNature").val();
    let assignNature = {
        "tableName": "AssignmentNature",
        "crudOperation": "VIEW",
        "columnData": [
            {
                "columnName": "assignmentNature",
                "columnValue": inputAssignNature
            }
        ]
    }
    recordGetPost(assignNature).then(function (res) {
        for (let i = 0; i < res.length; i++) {
            $("#type").html(`<option value="${res[i].type}">${res[i].type}</option>`);
            $("#frequency").html(`<option value="${res[i].frequency}">${res[i].frequency}</option>`);
        }
    });
}

function relevantEndDateUpdate() {
    let frequency = $("#frequency").val();
    let dateFormat = document.querySelector('input[name="dateFormat"]:checked').value;

    var sd1 = $("#relevantStartDate").val();
    $("#contractStartDate").val(sd1);
    var sd = new Date(sd1);

    var lastDay = new Date(sd.getFullYear(), sd.getMonth() + 1, 0);

    // let fullQuarterDate = sd.add(1).month();
    let qtday = lastDay.getDate();
    if (qtday < 10) qtday = '0' + qtday;
    let qtmonth = (parseInt(lastDay.getMonth()) + 1);
    if (qtmonth < 9) qtmonth = '0' + qtmonth.toString();
    let qtyear = lastDay.getFullYear();
    let quarterDate = qtyear + "-" + qtmonth + "-" + qtday;

    $("#relevantEndDate").val(quarterDate);
}

function relevantYearUpdate() {
    let sd = new Date($("#contractStartDate").val());
    let dateFormat = document.querySelector('input[name="dateFormat"]:checked').value;
    // let ed = $("#contractStartDate").val();


    if (sd != "Invalid Date") {

        let month = sd.getMonth();
        let year = sd.getFullYear();

        if (dateFormat == "Financial Year") {

            if (month == 0 || month == 1 || month == 2) {
                let previousYear = parseInt(year) - 1;
                var financialYear = previousYear + " - " + year;
                // $("#quarter").val("Q1");
            }
            else {
                let upcomingYear = parseInt(year) + 1;
                var financialYear = year + " - " + upcomingYear;
            }
            $("#relevantYear").val(financialYear);
        }
        if (dateFormat == "Calender Year") {
            $("#relevantYear").val(year);
        }
    }
}

function quarterUpdate() {
    let sd = $("#relevantStartDate").val();
    let dateFormat = document.querySelector('input[name="dateFormat"]:checked').value;
    let currentMon = new Date(sd);
    let mon = currentMon.getMonth();
    if (dateFormat == "Calender Year") {
        if (mon == 0 || mon == 1 || mon == 2) {
            var quarter = "Q1";
        }
        if (mon == 3 || mon == 4 || mon == 5) {
            var quarter = "Q2";
        }
        if (mon == 6 || mon == 7 || mon == 8) {
            var quarter = "Q3";
        }
        if (mon == 9 || mon == 10 || mon == 11) {
            var quarter = "Q4";
        }
        $("#quarter").val(quarter);
    }
    if (dateFormat == "Financial Year") {
        if (mon == 0 || mon == 1 || mon == 2) {
            var quarter = "Q4";
        }
        if (mon == 3 || mon == 4 || mon == 5) {
            var quarter = "Q1";
        }
        if (mon == 6 || mon == 7 || mon == 8) {
            var quarter = "Q2";
        }
        if (mon == 9 || mon == 10 || mon == 11) {
            var quarter = "Q3";
        }
        $("#quarter").val(quarter);
    }
}

function milestoneTableCreation() {
    let inputAssignNature = $("#assignNature").val();
    let assignNature = {
        "tableName": "Milestones",
        "crudOperation": "VIEW",
        "columnData": [
            {
                "columnName": "assignmentNature",
                "columnValue": inputAssignNature
            }
        ]
    }
    recordGetPost(assignNature).then(function (res) {
        var seq = 0;
        for (let i = 0; i < res.length; i++) {
            seq += 1;
            let rows = res[i];
            $("#milestoneTable").append(`<tr>
                <td>${rows.milestoneNumber}</td>
                <td contenteditable="true">${seq}</td>
                <td>${rows.milestones}</td>
                <td><input type="text" onblur="PaymentPercentAmount(this)"></input></td>
                <td class="percentAmnt"><input type="text"></input></td>
                <td class="advance"><input type="checkbox"></td>
                </tr>
            `);
        }
    });
}

function PaymentPercentAmount(thisval) {
    var feeEstimate = $("#feeEstimate").val();

    if (feeEstimate != "") {
        let percent = $(thisval).val();
        let sum = (feeEstimate * parseInt(percent)) / 100;
        $(thisval).parent().parent().find(".percentAmnt").children().val(sum);
    }
}


// Click of a Button

$("#addNew").click(function () {
    let count = $("#milestoneTable>tbody").children().length + 1;
    $("#milestoneTable").append(`<tr>
        <td></td>
        <td>${count}</td>
        <td contenteditable="true"></td>
        <td><input type="text" onblur="PaymentPercentAmount(this)"></input></td>
        <td class="percentAmnt"><input type="text"></input></td>
        <td class="advance"><input type="checkbox"></td>
        </tr>
    `);
    // $('#milestoneTable').DataTable({

    //     "aoColumnDefs": [
    //         { "bSortable": false, "aTargets": [ 0,4, 5, 6 ] }
    //       ]
    
    //   });
});



