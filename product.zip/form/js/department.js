var appId = 100000;

var getData = {
    "tableName": "AllDepartments",
    "crudOperation": "VIEW",
    "columnData": null
}
recordGetPost(getData).then(function(res){
    $("#appID").val(res.length + 1 + appId);
}); // Function recordGetPost End

$("#formSubmit").click(function () {
    let departmentName = $("#departmentName").val();
    let departmentHead = $("#departmentHead").val();

    var insert = {
        "tableName": "AllDepartments",
        "crudOperation": "INSERT",
        "columnData": [
            {
                "columnName": "departmentName",
                "columnValue": departmentName
            },
            {
                "columnName": "departmentHead",
                "columnValue": departmentHead
            }
        ]
    }
    recordOperation(insert);
});



































// var url = (window.location.href).toString().includes("?");

// function getAllDepartments(data) {
//     if (url == false) {
//         if (data.length > 0) {
//             var appID = data.length + 1;
//         }
//         else {
//             appID = 1;
//         }

//         // $("#appid").val(appID);

//         $("#formSubmit").click(function () {
//             let departmentName = $("#departmentName").val();
//             let departmentHead = $("#departmentHead").val();
//             // Department POST API
//             var departmentInsert = {
//                 "departmentName": departmentName,
//                 "departmentHead": departmentHead,
//                 "crudOperation": "INSERT"
//             }
//             fetch("http://localhost:86/api/Prototype/CRUDDepartments", {
//                 method: "POST",
//                 headers: { "Content-Type": "application/json", 'accept': 'text/plain' },
//                 body: JSON.stringify(departmentInsert)
//             }).then(res => res.text()).then(function (message) {
//                 console.log(message);
//                 window.location.reload();
//             });
//         });

//     }
//     if (url == true) {
//         $("#formUpdate").show();
//         $("#formSubmit").hide();
//         var editUrl = (window.location.href).toString().split("?");
//         var editId = editUrl[1].split("=");
//         $("#departmentName").val(editId[1].replaceAll("%20"," "));



//         $("#formUpdate").click(function () {
            
//             // let contract = $("#contractName").val();
//             let departmentName = $("#departmentName").val();
//             let departmentHead = $("#departmentHead").val();

//             // Department POST API
//             var departmentUpdate = {
//                 "departmentName": departmentName,
//                 "departmentHead": departmentHead,
//                 "crudOperation": "UPDATE"
//             }
//             fetch("http://localhost:86/api/Prototype/CRUDDepartments", {
//                 method: "POST",
//                 headers: { "Content-Type": "application/json", 'accept': 'text/plain' },
//                 body: JSON.stringify(departmentUpdate)
//             }).then(res => res.text()).then(function (message) {
//                 console.log(message);
//                 window.open("http://localhost:90/report/allDepartment.html", "_self");
//             });
//         });
//     }

// }