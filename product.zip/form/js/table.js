c = 0;

$("#addNewsf").click(function () {
    c += 1;
    $("#subForm>tbody").append(`
    <tr id="row${c}">
    <td>
        <div class="row mb-3">
            <div>
                <input type="text" class="form-control" id="columnName">
            </div>
        </div>
    </td>
    <td>
        <div class="row mb-3">
            <div>
                <select id="columnType">
                    <option value="varchar(255)">Text</option>
                    <option value="int">Number</option>
                    <option value="decimal">Decimal</option>
                </select>
            </div>
        </div>
    </td>
    <td>
        <div class="row mb-3">
            <div>
                <select id="columnNull">
                    <option value="NULL">Null</option>
                    <option value="NOT NULL">Not Null</option>
                </select>
            </div>
        </div>
    </td>
    <td>
        <div class="row mb-3">
            <div>
            <select id="columnConstraint">
                <option value=""></option>
                <option value="PRIMARY KEY">Primary Key</option>
            </select>
            </div>
        </div>
    </td>
    <td>
        <div class="row mb-3">
            <div>
                <input type="num" class="form-control" id="appID" disabled>
            </div>
        </div>
    </td>
</tr>    
    `);
});


$("#formSubmit").click(function () {
    var tableName = $("#tableName").val();
    var sfRows = document.querySelectorAll("#subForm>tbody tr");
    colArray = [];
    for (let i = 0; i < sfRows.length; i++) {

        var tableRows = document.querySelectorAll(`#row${i + 1}`);
        var rowVal = {};
        for (let j = 0; j < tableRows.length; j++) {
            var colName = $(`#row${i + 1}`).find("#columnName").val();
            var colType = $(`#row${i + 1}`).find("#columnType").val();
            var colNull = $(`#row${i + 1}`).find("#columnNull").val();
            var colConstraint = $(`#row${i + 1}`).find("#columnConstraint").val();

            rowVal.columnName = colName;
            rowVal.columnType = colType;
            rowVal.columnNull = colNull;
            rowVal.columnConstraint = colConstraint;
        }
        colArray.push(rowVal);
    }
    console.log(colArray);
    var tableObj = {
        "tableNameForCreation": tableName,
        "columnDetailsForCreation": colArray
    }
    tableCreation(tableObj);
});
