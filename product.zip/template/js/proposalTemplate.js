const params = new URLSearchParams(window.location.search);
var clientName = params.get('client');

var getData = {
    "tableName": "ClientMaster",
    "crudOperation": "VIEW",
    "columnData": [
        {
            "columnName": "clientName",
            "columnValue": clientName
        }
    ]
}
recordGetPost(getData).then(function (res) {
    var getClientName = res[0].clientName;
    var email = res[0].email;
    $("#send").click(function () {
            // Choose the element that your content will be rendered to.
            const element = document.getElementById('proposal');
            // Choose the element and save the PDF for your user.
            var pdf = html2pdf().from(element);

        var link = "mailto:" + email
            + "?cc=gokul@ggsh.in"
            + "&subject=" + encodeURIComponent("Contract Proposal")
            + "&body=" + encodeURIComponent(`Dear ${getClientName}, \n
        Attached contract proposal here \n \n ${pdf}`)
            ;

        window.location.href = link;

        //All Files Post API
        var proposalFile = {
            "tableName": "AllFiles",
            "crudOperation": "INSERT",
            "columnData": [
                {
                    "columnName": "clientName",
                    "columnValue": "Test"
                },
                {
                    "columnName": "proposal",
                    "columnValue": pdf
                }
            ]
        }
        recordOperation(proposalFile);
    });
});
