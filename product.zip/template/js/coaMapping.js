$(document).ready(function(){
    // var filter = document.querySelectorAll("#filter");
    
    // Call the dataTables jQuery plugin
    // var dataTable = document.querySelectorAll("#dataTable");
    // for(let i=0;i<dataTable.length;i++)
    // {
    // //   var tabId = dataTable[i].id;
    // }
    // $("#dataTable").DataTable();
  

    // window.onload = () => {
    //     console.log("test");
    //     var tableHead = document.querySelectorAll(".tabrow");
    //     for(let i=0;i<tableHead.length;i++){
    //         // $(this).append(`<select id="filter"></select>`); 
    //         tableHead[i].innerHTML = `<select id="filter"></select>`;

    //     }
    //         var tableData = document.querySelectorAll(".tabdata");
    //         for(let j=0;j<tableData.length;j++){
    //             var child = tableData[j].children;
    //             // console.log(child);
    //             var colList1 = [];
    //             var colList2 = [];
    //             var colList3 = [];
    //             var colList4 = [];
    //             for(let k=0;k<child.length;k++){
    //                 // lis.push(child[k].innerHTML);
    //                 if( "col"+j == (child[k].className).toString()){
    //                     col = "colList"+j;
    //                     colList1.push(child[k].innerHTML);
    //                 }
    //             }
    //             console.log(colList1);
    //         //     var setdata = new Set(lis);
    //         //     console.log(setdata);
    //         //     // tableHead[i].children[0].innerHTML = `<option>${}</option>`;
    //         }
    // }
// *************************************************************************************************************************************************
    var req = new XMLHttpRequest();
    req.onload = function(){
        let data = JSON.parse(this.responseText);
        ptdata(data);
        window.onload = function(){
            $(document).ready(function() {
                $('#dataTable').DataTable();
            });
        }
    }
    req.open("GET","http://localhost:86/api/Prototype/getPTData");
    req.send();


    function ptdata(data){
        let sno = 0;
        for(let i=0;i<data.length;i++){
            sno += 1;
            $("#tddataBody").append(`<tr class=rawrow><td>${sno}</td>
            <td>${data[i].speedID}</td>
            <td>${data[i].sourceID}</td>
            <td>${data[i].client_name}</td>
            <td>${data[i].transDate}</td>
            <td>${data[i].transRef}</td>
            <td>${data[i].raw_COA}</td>
            <td>${data[i].debit}</td>
            <td>${data[i].credit}</td>
            <td>${data[i].ggsH_COA}</td>
            </tr>`);
        }

    }


    var req2 = new XMLHttpRequest();
    req2.onload = function(){
        let data2 = JSON.parse(this.responseText);
        coaMapping(data2);
        ggshCoaAutoFill();
        $(document).ready(function() {
            $('#dataTable1').DataTable();
        });
    }
    req2.open("GET","http://localhost:86/api/Prototype/getCOAMapping");
    req2.send();


    function coaMapping(data2){
        let sno = 0;
        for(let i=0;i<data2.length;i++){
            sno += 1;
            $("#coaMapping").append(`<tr class="coarow"><td>${sno}</td>
            <td>${data2[i].speedid}</td>
            <td>${data2[i].client_name}</td>
            <td>${data2[i].transdate}</td>
            <td>${data2[i].raw_coa}</td>
            <td><select id="selectGgshCoa"></select></td>
            </tr>`);
        }

        var selectCoa = document.querySelectorAll("#selectGgshCoa");
        var req1 = new XMLHttpRequest();
            req1.onload = function(){
            let data1 = JSON.parse(this.responseText);
            coaMappingData(data1);
            ggshCoaAutoFill();
            $(document).ready(function() {
                $('#dataTable1').DataTable();
            });
        }
        req1.open("GET","http://localhost:86/api/Prototype/getPTGGSHCOA");
        req1.send();

        function coaMappingData(data){
            for(let j=0;j<selectCoa.length;j++){
                for(let k=0;k<data.length;k++){
                    var coa = data[k].ggsH_COA;
                    selectCoa[j].innerHTML += `<option value="${coa}">${coa}</option>`;
                    // console.log(selectCoa[j])
                }
            }
        }
        
    }




    const coaRow = document.getElementsByClassName("coarow");
    const rawRow = document.getElementsByClassName("rawrow");

    function ggshCoaAutoFill(){
        rawCoaList = [];
        for(let i=0;i<coaRow.length;i++){
            for(let j=0;j<rawRow.length;j++){
                let rawdata = rawRow[j].children[6].innerHTML;
                rawcoaMap = coaRow[i].children[4].innerHTML;
                if(rawcoaMap.includes(rawdata) == true && rawRow[j].children[9].innerHTML != ""){
                    rawCoaList.push(rawRow[j].children[9].innerHTML);
                }
            }
            var len = rawCoaList.length - 1;
            var test = rawCoaList[len].toString();
            coaRow[i].children[5].children[0].value = test;
        }
    }


    const coaSubmit = document.getElementById("coaSubmit");
    coaSubmit.onclick = function(){
        let obj = {"speedId":[]};
    for(let i=0;i<coaRow.length;i++){
        var coaSpeedId = coaRow[i].children[1].innerHTML;

        for(let j=0;j<rawRow.length;j++){
            var rawSpeedId = rawRow[j].children[1].innerHTML;
            if(rawSpeedId == coaSpeedId)
            {
                rawRow[j].children[9].innerHTML = coaRow[i].children[5].children[0].value;
            }
        }
    }
    }



});
