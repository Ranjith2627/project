var url = window.location.href.toString();
var query1 = url.split("?");
if(query1.length == 0){

    var getData = {
        "tableName":"ClientMaster",
        "crudOperation":"VIEW",
        "columnData":null,
    }
    recordGetPost(getData).then(function(res){
        $("#client").text(res[0].clientName);
        for(let i=0;i<res.length;i++){
            var rows = res[i];
            $("#clientContainer").append(`<a class="collapse-item" href="http://localhost:90/template/clientTemplate.html?client=${rows.clientName}">${rows.clientName}</a>`);
        }
    });
}
else{
    var query = query1[1].split("&");
    var params = [];
    for (let i = 0; i < query.length; i++) {
        var item = query[i].split("=");
        params.push(item[1].replaceAll("%20", " "));
    }
        $("#client").text(params[0]);
}




var getData = {
    "tableName":"AllDepartments",
    "crudOperation":"VIEW",
    "columnData":null,
}
recordGetPost(getData).then(function(res){
    $("#client").text(res[0].clientName);
    for(let i=0;i<res.length;i++){
        var rows = res[i];
        $("#navbar").append(`<a href="http://localhost:90/template/clientTemplate.html?client=${params[0]}&dept=${rows.departmentName}">${rows.departmentName} <span class="badge bg-danger text-white">0</span></a>`);
    }
});



// function getAllDepartments(data) {
//     for (let i = 0; i < data.length; i++) {
//         var rows = data[i];
//         $("#navbar").append(`<a href="http://localhost:90/template/clientTemplate.html?client=${params[0]}&dept=${rows.departmentName}">${rows.departmentName} <span class="badge bg-danger text-white">0</span></a>`)
//     }
// }

// function getAllClients(data) {

//     for (let i = 0; i < data.length; i++) {
//         var rows = data[i];
//         $("#clientContainer").append(`<a class="collapse-item" href="http://localhost:90/template/clientTemplate.html?client=${rows.clientName}">${rows.clientName}</a>`)
//     }
// }

// if (params[1] == "Audit") {

//     // $(".nav-content").html(`
//     //     <div class="row shadow">
//     //         <div class="card col-lg-1">0</div>
//     //         <div class="card col-lg-1">0</div>
//     //         <div class="card col-lg-1">0</div>
//     //         <div class="card col-lg-1">0</div>
//     //     </div>
//     // `);



//     //   $(".nav-content").html(`
//     //   <div class="card shadow mb-4 p-0">
//     //   <div class="card-header py-3">
//     //       <h6 class="m-0 font-weight-bold text-primary">COA Mapping</h6>
//     //   </div>

//     //   <div class="card-body">
//     //       <div class="table-responsive" style="height:250p;">
//     //           <table class="table table-bordered" id="dataTable1" width="100%" cellspacing="0">
//     //               <thead style="position:sticky;top:-1px;background:#00c991;color:#fff;">
//     //                   <tr>
//     //                       <th>S.No</th>
//     //                       <th>Speed Id</th>
//     //                       <th>Client Name</th>
//     //                       <th>Transaction Date</th>
//     //                       <th>Raw COA</th>
//     //                       <th>GGSH COA</th>
//     //                   </tr>
//     //               </thead>
//     //               <tbody id="coaMapping">

//     //               </tbody>
//     //           </table>
//     //       </div>
//     //       <button type="button" class="btn btn-primary" style="margin-left:50%;transform:translate-x(-50%);" id="coaSubmit">Apply</button>
//     //   </div>
//     // </div>

//     // <div class="card shadow mb-4 p-0">
//     //   <div class="card-header py-3">
//     //       <h6 class="m-0 font-weight-bold text-primary">Raw Data</h6>
//     //   </div>

//     //   <div class="card-body">
//     //       <div class="table-responsive" style="height:300px;padding:0px;">
//     //           <table class="table table-bordered" id="dataTable" cellspacing="0">
//     //               <thead style="position:sticky;top:-1px;background:#00c991;color:#fff;">
//     //                   <tr>
//     //                       <th>S.No</th>
//     //                       <th>Speed ID</th>
//     //                       <th>Source ID</th>
//     //                       <th>Client Name</th>
//     //                       <th>Transaction Date</th>
//     //                       <th>Transaction Reference</th>
//     //                       <th>Raw COA</th>
//     //                       <th>Debit</th>
//     //                       <th>Credit</th>
//     //                       <th>GGSH COA</th>
//     //                   </tr>
//     //               </thead>
//     //               <tbody id="tddataBody">

//     //               </tbody>
//     //           </table>
//     //       </div>
//     //   </div>
//     // </div>
//     //   `);

// }



// function minimize(thisval) {

//     $("#clientContainer").hide();
//     $(thisval).html(`<i class="fa-solid fa-circle-arrow-right"></i>`);
//     $(thisval).attr("onclick", "maximize(this)");
//     $(thisval).attr("style", "position:absolute;left:250px;color:#0090a5;");
//     $(".content").attr("style", "margin-left:10px;");
//     // $(this).toggleClass("miniToggle");
//     // $(".content").toggleClass("contentToggle");
// }

// function maximize(thisval) {
//     $("#clientContainer").show();
//     $(thisval).html(`<i class="fa-solid fa-circle-arrow-left"></i>`);
//     $(thisval).attr("onclick", "minimize(this)");
//     $(thisval).attr("style", "position:absolute;left:340px;color:#fff;");
//     $(".content").attr("style", "color:red;");
// }


// function clientSearch() {
//     var filter = $("#cliSearch").val().toUpperCase();

//     var clients = document.querySelectorAll("#clientContainer a");
//     for (i = 0; i < clients.length; i++) {
//         var td = clients[i];
//         if (td) {
//             var txtValue = td.textContent || td.innerText;
//             if (txtValue.toUpperCase().indexOf(filter) > -1) {
//                 clients[i].style.display = "";
//             } else {
//                 clients[i].style.display = "none";
//             }
//         }
//     }
// }




// function coaDisplay() {
//     $(".nav-content").html(`
//       <div class="card shadow mb-4 p-0">
//       <div class="card-header py-3">
//           <h6 class="m-0 font-weight-bold text-primary">COA Mapping</h6>
//       </div>

//       <div class="card-body">
//           <div class="table-responsive" style="height:250p;">
//               <table class="table table-bordered" id="dataTable1" width="100%" cellspacing="0">
//                   <thead style="position:sticky;top:-1px;background:#00c991;color:#fff;">
//                       <tr>
//                           <th>S.No</th>
//                           <th>Speed Id</th>
//                           <th>Client Name</th>
//                           <th>Transaction Date</th>
//                           <th>Raw COA</th>
//                           <th>GGSH COA</th>
//                       </tr>
//                   </thead>
//                   <tbody id="coaMapping">

//                   </tbody>
//               </table>
//           </div>
//           <button type="button" class="btn btn-primary" style="margin-left:50%;transform:translate-x(-50%);" id="coaSubmit">Apply</button>
//       </div>
//     </div>

//     <div class="card shadow mb-4 p-0">
//       <div class="card-header py-3">
//           <h6 class="m-0 font-weight-bold text-primary">Raw Data</h6>
//       </div>

//       <div class="card-body">
//           <div class="table-responsive" style="height:300px;padding:0px;">
//               <table class="table table-bordered" id="dataTable" cellspacing="0">
//                   <thead style="position:sticky;top:-1px;background:#00c991;color:#fff;">
//                       <tr>
//                           <th>S.No</th>
//                           <th>Speed ID</th>
//                           <th>Source ID</th>
//                           <th>Client Name</th>
//                           <th>Transaction Date</th>
//                           <th>Transaction Reference</th>
//                           <th>Raw COA</th>
//                           <th>Debit</th>
//                           <th>Credit</th>
//                           <th>GGSH COA</th>
//                       </tr>
//                   </thead>
//                   <tbody id="tddataBody">

//                   </tbody>
//               </table>
//           </div>
//       </div>
//     </div>
//       `);

//     var req = new XMLHttpRequest();
//     req.onload = function () {
//         let data = JSON.parse(this.responseText);
//         ptdata(data);
//         window.onload = function () {
//             $(document).ready(function () {
//                 $('#dataTable').DataTable();
//             });
//         }
//     }
//     req.open("GET", "http://localhost:86/api/Prototype/getPTData");
//     req.send();


//     function ptdata(data) {
//         let sno = 0;
//         let testSno = 0
//         let debT = 0;
//         let credT = 0;
//         for (let i = 0; i < data.length; i++) {

//             $("#test").append(`<tr><td>Total</td><td> </td><td>${debT}</td><td>${credT}</td></tr>`);

//             console.log("test");
//             if (data[i].raw_COA == "Rent") {
//                 testSno += 1;
//                 if (data[i].credit == "") {
//                     var cred = 0;
//                 }
//                 else {
//                     cred = data[i].credit;
//                 }
//                 if (data[i].debit == "") {
//                     var deb = 0;
//                 }
//                 else {
//                     deb = data[i].debit;
//                 }
//                 debT += deb;
//                 credT += cred;
//                 $("#test").append(`<tr><td>${data[i].transRef}</td><td>${testSno}</td><td>${data[i].debit}</td><td>${data[i].credit}</td></tr>`);
//             }



//             sno += 1;
//             $("#tddataBody").append(`<tr class=rawrow><td>${sno}</td>
//               <td>${data[i].speedID}</td>
//               <td>${data[i].sourceID}</td>
//               <td>${data[i].client_name}</td>
//               <td>${data[i].transDate}</td>
//               <td>${data[i].transRef}</td>
//               <td>${data[i].raw_COA}</td>
//               <td>${data[i].debit}</td>
//               <td>${data[i].credit}</td>
//               <td>${data[i].ggsH_COA}</td>
//               </tr>`);
//         }

//         $("#test").append(`<tr><td>Total</td><td> </td><td>${debT}</td><td>${credT}</td></tr>`);

//     }


//     var req2 = new XMLHttpRequest();
//     req2.onload = function () {
//         let data2 = JSON.parse(this.responseText);
//         coaMapping(data2);
//         ggshCoaAutoFill();
//         $(document).ready(function () {
//             $('#dataTable1').DataTable();
//         });
//     }
//     req2.open("GET", "http://localhost:86/api/Prototype/getCOAMapping");
//     req2.send();


//     function coaMapping(data2) {
//         let sno = 0;
//         for (let i = 0; i < data2.length; i++) {
//             sno += 1;
//             $("#coaMapping").append(`<tr class="coarow"><td>${sno}</td>
//               <td>${data2[i].speedid}</td>
//               <td>${data2[i].client_name}</td>
//               <td>${data2[i].transdate}</td>
//               <td>${data2[i].raw_coa}</td>
//               <td><select id="selectGgshCoa"></select></td>
//               </tr>`);
//         }

//         var selectCoa = document.querySelectorAll("#selectGgshCoa");
//         var req1 = new XMLHttpRequest();
//         req1.onload = function () {
//             let data1 = JSON.parse(this.responseText);
//             coaMappingData(data1);
//             ggshCoaAutoFill();
//             $(document).ready(function () {
//                 $('#dataTable1').DataTable();
//             });
//         }
//         req1.open("GET", "http://localhost:86/api/Prototype/getPTGGSHCOA");
//         req1.send();

//         function coaMappingData(data) {
//             for (let j = 0; j < selectCoa.length; j++) {
//                 for (let k = 0; k < data.length; k++) {
//                     var coa = data[k].ggsH_COA;
//                     selectCoa[j].innerHTML += `<option value="${coa}">${coa}</option>`;
//                     // console.log(selectCoa[j])
//                 }
//             }
//         }

//     }




//     const coaRow = document.getElementsByClassName("coarow");
//     const rawRow = document.getElementsByClassName("rawrow");

//     function ggshCoaAutoFill() {
//         rawCoaList = [];
//         for (let i = 0; i < coaRow.length; i++) {
//             for (let j = 0; j < rawRow.length; j++) {
//                 let rawdata = rawRow[j].children[6].innerHTML;
//                 rawcoaMap = coaRow[i].children[4].innerHTML;
//                 if (rawcoaMap.includes(rawdata) == true && rawRow[j].children[9].innerHTML != "") {
//                     rawCoaList.push(rawRow[j].children[9].innerHTML);
//                 }
//             }
//             var len = rawCoaList.length - 1;
//             var test = rawCoaList[len].toString();
//             coaRow[i].children[5].children[0].value = test;
//         }
//     }


//     const coaSubmit = document.getElementById("coaSubmit");
//     coaSubmit.onclick = function () {
//         let obj = { "speedId": [] };
//         for (let i = 0; i < coaRow.length; i++) {
//             var coaSpeedId = coaRow[i].children[1].innerHTML;

//             for (let j = 0; j < rawRow.length; j++) {
//                 var rawSpeedId = rawRow[j].children[1].innerHTML;
//                 if (rawSpeedId == coaSpeedId) {
//                     rawRow[j].children[9].innerHTML = coaRow[i].children[5].children[0].value;
//                 }
//             }
//         }
//     }
// }




// function finance() {
//     $(".nav-content").html(`
      

//     <h5>SDRIVE SERVICES PRIVATE LIMITED <br>Balance Sheet as at March 31, 2022</h5>

//                         <table class="table">
//                             <tr>
//                                 <th rowspan="2">Particulars</th>
//                                 <th rowspan="2">Note</th>
//                                 <th>As at 31 March, 2022</th>
//                                 <th>As at 31 March, 2022</th>
//                             </tr>
//                             <tr>
//                                 <th>Rs</th>
//                                 <th>Rs</th>
//                             </tr>

//                             <tr>
//                                 <td><b>EQUITY AND LIABILITIES</b> <br> <b>Shareholders’ funds</b></td>
//                                 <td></td>
//                                 <td></td>
//                                 <td></td>
//                             </tr>
//                             <tbody id="test">
                                
//                             </tbody>
//                         </table>

                        
//                             <table width='80%'>
//                                 <tr>
//                                     <th> As per our report of even date attached <br>
//                                     For GGSH & Co. LLP 	 <br>
//                                     Chartered Accountants  	<br>
//                                     FRN:S200090 	
//                                    </th>
//                                    <th>For and behalf of the board of directors		
//                                    </th>
//                                 </tr>
//                             </table>

//                             <br>

//                             <table width='80%'>
//                                 <tr>
//                                     <th> 
//                                     G.Gokulakrishnan<br>
//                                     M.No:229125<br>
//                                     UDIN: 22229125BCEOKT4176<br>
//                                     Date: 07/09/2022<br>
//                                     Place: Chennai
//                                    </th>
//                                    <th>
//                                     THIYAGARAJ VIJAYARAJ<br>
//                                     Director<br>
//                                     DIN:08351498		
//                                    </th>
//                                    <th>
//                                    MARAPAN SHANMUGAM SARAVANAN<br>
//                                     Director<br>
//                                     DIN: 08351499
//                                     </th>
//                                 </tr>
//                             </table>

//       `);

//     var req = new XMLHttpRequest();
//     req.onload = function () {
//         let data = JSON.parse(this.responseText);
//         ptdata(data);
//         window.onload = function () {
//             $(document).ready(function () {
//                 $('#dataTable').DataTable();
//             });
//         }
//     }
//     req.open("GET", "http://localhost:86/api/Prototype/getPTData");
//     req.send();


//     function ptdata(data) {
//         let sno = 0;
//         let testSno = 0
//         let debT = 0;
//         let credT = 0;
//         for (let i = 0; i < data.length; i++) {


//             if (data[i].raw_COA == "Cash") {
//                 testSno += 1;
//                 if (data[i].credit == "") {
//                     var cred = 0;
//                 }
//                 else {
//                     cred = data[i].credit;
//                 }
//                 if (data[i].debit == "") {
//                     var deb = 0;
//                 }
//                 else {
//                     deb = data[i].debit;
//                 }
//                 debT += parseInt(deb);
//                 credT += parseInt(cred);
//                 $("#test").append(`<tr><td>${data[i].raw_COA}</td><td>${testSno}</td><td>${data[i].debit}</td><td>${data[i].credit}</td></tr>`);
//             }





            
//         }
//         $("#test").append(`<tr><th>Total</th><th> </th><th>${debT}</th><th>${credT}</th></tr>`);

//         let testSno1 = 0
//         let debT1 = 0;
//         let credT1 = 0;


//         for (let i = 0; i < data.length; i++) {


//             if (data[i].raw_COA == "Bank") {
//                 testSno1 += 1;
//                 if (data[i].credit == "") {
//                     var cred = 0;
//                 }
//                 else {
//                     cred = data[i].credit;
//                 }
//                 if (data[i].debit == "") {
//                     var deb = 0;
//                 }
//                 else {
//                     deb = data[i].debit;
//                 }
//                 debT1 += parseInt(deb);
//                 credT1 += parseInt(cred);
//                 $("#test").append(`<tr><td>${data[i].raw_COA}</td><td>${testSno}</td><td>${data[i].debit}</td><td>${data[i].credit}</td></tr>`);
//             }

//         }

//         $("#test").append(`<tr><th>Total</th><th> </th><th>${debT1}</th><th>${credT1}</th></tr>`);

//         $("#test").append(`<tr><th>Total</th><th> </th><th>${debT1 + debT}</th><th>${credT1 + credT}</th></tr>`);

//     }






//     const coaRow = document.getElementsByClassName("coarow");
//     const rawRow = document.getElementsByClassName("rawrow");

//     function ggshCoaAutoFill() {
//         rawCoaList = [];
//         for (let i = 0; i < coaRow.length; i++) {
//             for (let j = 0; j < rawRow.length; j++) {
//                 let rawdata = rawRow[j].children[6].innerHTML;
//                 rawcoaMap = coaRow[i].children[4].innerHTML;
//                 if (rawcoaMap.includes(rawdata) == true && rawRow[j].children[9].innerHTML != "") {
//                     rawCoaList.push(rawRow[j].children[9].innerHTML);
//                 }
//             }
//             var len = rawCoaList.length - 1;
//             var test = rawCoaList[len].toString();
//             coaRow[i].children[5].children[0].value = test;
//         }
//     }


//     const coaSubmit = document.getElementById("coaSubmit");
//     coaSubmit.onclick = function () {
//         let obj = { "speedId": [] };
//         for (let i = 0; i < coaRow.length; i++) {
//             var coaSpeedId = coaRow[i].children[1].innerHTML;

//             for (let j = 0; j < rawRow.length; j++) {
//                 var rawSpeedId = rawRow[j].children[1].innerHTML;
//                 if (rawSpeedId == coaSpeedId) {
//                     rawRow[j].children[9].innerHTML = coaRow[i].children[5].children[0].value;
//                 }
//             }
//         }
//     }
// }


