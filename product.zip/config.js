
// Get All Clients API
async function recordGetPost(data){
    var fe = await fetch("http://localhost:86/api/Speed/DynamicGetDataTable", {
        method: "POST",
        headers: { "Content-Type": "application/json", 'accept': 'text/plain' },
        body: JSON.stringify(data)
    })    
    var jsonfe = await fe.json();
    return jsonfe;
}


//CRUD Operation API
function recordOperation(record) {
    fetch("http://localhost:86/api/Speed/DynamicCRUDTables", {
        method: "POST",
        headers: { "Content-Type": "application/json", 'accept': 'text/plain' },
        body: JSON.stringify(record)
    }).then(res => res.text()).then(function (message) {
        console.log(message);
        // window.location.reload();
    });
}

//CRUD Table Creation API
function tableCreation(record) {
    
    fetch("http://localhost:86/api/Speed/DynamicTableCreation", {
        method: "POST",
        headers: { "Content-Type": "application/json", 'accept': 'text/plain' },
        body: JSON.stringify(record)
    }).then(res => res.text()).then(function (message) {
        console.log(message);
        // window.location.reload();
    });
}


//CRUD Table Column Modification API
function tableColumnModify(record) {
    
    fetch("http://localhost:86/api/Speed/DynamicTableModification", {
        method: "POST",
        headers: { "Content-Type": "application/json", 'accept': 'text/plain' },
        body: JSON.stringify(record)
    }).then(res => res.text()).then(function (message) {
        console.log(message);
        // window.location.reload();
    });
}



// // Get All AssignmentNature API
// fetch("http://localhost:86/api/Prototype/getAssignmentNature").then((response) => response.json()).then(function (data) {
//     getAllAssignmentNature(data);
// });

// // Get All Departments API
// fetch("http://localhost:86/api/Prototype/getAllDepartments").then((response) => response.json()).then(function (data) {
//     getAllDepartments(data);
// });

// // Get All Employees API
// fetch("http://localhost:86/api/Prototype/getAllEmployees").then((response) => response.json()).then(function (data) {
//     getAllEmployees(data);
// });

// // Get All Contracts API
// fetch("http://localhost:86/api/Prototype/getAllContracts").then((response) => response.json()).then(function (data) {
//     getAllContracts(data);
// });

// //Get All Projects
// fetch("http://localhost:86/api/Prototype/getAllProjects").then((response) => response.json()).then(function (data) {
//     getAllProjects(data);
// });



// // function addColumn(){


// //     let table = $("#reportTable tr");
// //     console.log(table);
// //     // for()
// //     // $("#reportTable tbody").append(`<th>New Column</th>`);
// // }


